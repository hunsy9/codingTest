from problem import Problem

class Setup(Problem):
    def __init__(self):
        self._delta = 0.01
        self._alpha = 0.01
        self._dx = 10 ** (-4)