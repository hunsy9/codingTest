from setup import *
from problem import *
LIMIT_STUCK = 100

class HillClimbing(Problem):
    def __init__(self):
        self._pType=0
        self._aType=0
        super().__init__()

    def setVariables(self,aType,pType):
        self._pType = pType
        self._aType = aType

    def displaySetting(self):
        print('common information')

class SteepestAscent(HillClimbing):

    def displaySetting(self):
        print('additional setting')

    def run(self,p):
        p.setVariables()
        current = p.randomInit()  # 'current' is a list of values
        valueC = p.evaluate(current)
        while True:
            neighbors = p.mutants(current)  # 인접 값들 구하기
            successor, valueS = self.bestOf(neighbors, p)  # 인접한 값들 중에 최선의 값 구하기
            if valueS >= valueC:
                break
            else:
                current = successor
                valueC = valueS
        p.storeResult(current,valueC)


    def bestOf(self, neighbors, p):
        tempArray = []
        for i in range(len(neighbors)):
            tempArray.append(p.evaluate(neighbors[i]))
        bestValue = min(tempArray)
        best = neighbors[tempArray.index(bestValue)]
        return best, bestValue

class FirstChoice(HillClimbing):
    def displaySetting(self):
        print('additional setting')

    def run(self,p):
        p.setVariables()
        current = p.randomInit()  # 'current' is a list of values
        valueC = p.evaluate(current)  # 랜덤하게 나온 값 evaluate
        i = 0
        while i < LIMIT_STUCK:  # 한계횟수까지 반복
            successor = p.randomMutant(current)  # 랜덤하게 mutant를 뽑음
            valueS = p.evaluate(successor)  # mutant로 값 evaluate
            if valueS < valueC:  # 새로 뽑은 것이 오차가 적다면??
                current = successor  # 새로 뽑은 mutant로 초기화
                valueC = valueS
                i = 0  # Reset stuck counter
            else:
                i += 1

        p.storeResult(current,valueC)


class GradientDescent(HillClimbing):
    def displaySetting(self):
        print('additional setting')

    def run(self,p):
        p.setVariables()
        current = p.randomInit()  # 'current' is a list of value , problem에서 랜덤으로 x1x2뽑음
        valueC = p.evaluate(current)
        while True:
            nextP = p.takeStep(current, valueC)
            valueN = p.evaluate(nextP)
            if valueN >= valueC:
                break
            else:
                current = nextP
                valueC = valueN
        p.storeResult(current,valueC)