from problem import Numeric,TSP
from optimizer import *

def invalid(pType,aType):
    if pType == 2 and aType == 3:
        print()
        print("You cannot choose Gradient Descent with TSP")
        return 0
    return 1

def selectProblem():
    print("Select the problem type:")
    print(" 1. Numerical Optimization")
    print(" 2. TSP")
    pType = int(input("Enter the number: "))
    if pType == 1:
        p = Numeric()
    if pType == 2:
        p = TSP()
    return p,pType

def selectAlgorithm(pType):
    while(True):
        print()
        print("Select the search algorithm:")
        print(" 1. Steepest-Ascent")
        print(" 2. First-Choice")
        print(" 3. Gradient-Descent")
        aType = int(input("Enter the number: "))
        if invalid(pType,aType):
            break

    optimizers = { 1:'SteepestAscent()',
                   2: 'FirstChoice()',
                   3: 'GradientDescent()'}
    alg = eval(optimizers[aType])
    alg.setVariables(aType,pType)
    return alg

def main():
    p,pType = selectProblem()
    print(p,pType)
    alg = selectAlgorithm(pType)
    print(alg)
    alg.displaySetting()
    alg.run(p)
    p.describe()
    p.report(p.getSolution(),p.getValue())

main()